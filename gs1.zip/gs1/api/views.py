from django.shortcuts import render
from .models import Student
from django.http import HttpResponse
from rest_framework.views import APIView
from django.http import Http404
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer
from .serializers import StudentSerializer
from rest_framework import status
# Create your views here.
#model object -single student data
# def student_details(request,pk):
#     stu=Student.objects.get(id=pk)
#     serializer=StudentSerializer(stu)
#     # print(serializer)
#     # print(serializer.data)
    

#     json_data=JSONRenderer().render(serializer.data)
#     # print(json_data)
#     #we can also return it like 
#     #return JsonResponse(serializer.data)#then no need to do Render
#     return HttpResponse(json_data,content_type='application/json')
#query set -all student data
# def student_list(request):
#     stu=Student.objects.all()
#     serializer=StudentSerializer(stu,many=True)
#     # print(serializer)
#     # print(serializer.data)
    

#     json_data=JSONRenderer().render(serializer.data)
#     # print(json_data)
#     return HttpResponse(json_data,content_type='application/json')

class studentList(APIView):
    def get_object(Self,pk):

        try:
            return Student.objects.get(pk=pk)
        except Student.DoesNotExist:
            raise Http404
    def get(Self,request,format=None):
        student=Student.objects.all()
        serializer=StudentSerializer(student,many=True)
        return Response(serializer.data)
    
    def put(self,request,pk,format=None):
        student=self.get_object(pk)
        serializer=StudentSerializer(student,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
    def delete(self,request,pk,format=None):
        student=self.get_object(pk)
        student.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    def post(self,request,format=None):
        serializer=StudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
class Student_details(APIView):
    def get_object(Self,pk):

        try:
            return Student.objects.get(pk=pk)
        except Student.DoesNotExist:
            raise Http404
    def get(Self,request,format=None):
        student=Student.objects.all()
        serializer=StudentSerializer(student,many=True)
        return Response(serializer.data)
    
    def put(self,request,pk,format=None):
        student=self.get_object(pk)
        serializer=StudentSerializer(student,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
    def delete(self,request,pk,format=None):
        student=self.get_object(pk)
        student.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)