import requests
import json

URL=" "
data={
    'name':'shivani',
    'roll':101,
    'city':'Ranchi'
}
json_data=json.dumps(data)


r=requests.post(url=URL,data=json_data)
dsata=r.json()
print(data)